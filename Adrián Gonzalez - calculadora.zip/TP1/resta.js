function resta(num1, num2){
    let resultadoResta = num1 - num2;
    return resultadoResta;
}

module.exports = resta;