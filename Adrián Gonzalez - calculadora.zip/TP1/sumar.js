function sumar(num1, num2){
    let resultadoSuma = num1 + num2;
    return resultadoSuma;
}

module.exports = sumar;